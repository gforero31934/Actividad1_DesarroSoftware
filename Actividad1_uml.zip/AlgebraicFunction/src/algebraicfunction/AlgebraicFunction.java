/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package algebraicfunction;

/**
 *
 * @author nemit
 */
public class AlgebraicFunction {

    // Método estático para calcular el valor de la función algebraica
    public static int calculateFunction(int x, int y) {
        return x * x + 2 * x * y + y * y;
    }

    public static void main(String[] args) {
        // Valores de ejemplo para x e y
        int x = 3;
        int y = 4;

        // Llamada al método para calcular la función
        int result = calculateFunction(x, y);

        // Mostrar el resultado
        System.out.println("El valor de la función f(" + x + ", " + y + ") es: " + result);
    }
}
