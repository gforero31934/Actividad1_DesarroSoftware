/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package terrenos;

/**
 *
 * @author nemit
 */
import java.util.Scanner;

public class Terrenos {

    // Función para calcular el área de un rectángulo
    public static double calcularAreaRectangulo(double base, double altura) {
        return base * altura;
    }

    // Función para calcular la hipotenusa de un triángulo rectángulo
    public static double calcularHipotenusa(double cateto1, double cateto2) {
        return Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));
    }

    // Función para calcular el área de un triángulo
    public static double calcularAreaTriangulo(double base, double altura) {
        return 0.5 * base * altura;
    }

    // Función para calcular el perímetro del terreno
    public static double calcularPerimetro(double ladoA, double ladoB, double ladoC) {
        return ladoA + ladoB + ladoC;
    }

    public static void main(String[] args) {
        // Crear un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario las dimensiones de los tres lados
        System.out.print("Ingrese el lado A del terreno en metros: ");
        double ladoA = scanner.nextDouble();
        System.out.print("Ingrese el lado B del terreno en metros: ");
        double ladoB = scanner.nextDouble();
        System.out.print("Ingrese el lado C del terreno en metros: ");
        double ladoC = scanner.nextDouble();

        // Calcular la hipotenusa para verificar si el terreno puede ser un triángulo rectángulo
        double hipotenusa = calcularHipotenusa(ladoA, ladoB);

        // Calcular el área del triángulo con base y altura (A y B en este caso)
        double areaTriangulo = calcularAreaTriangulo(ladoA, ladoB);

        // Calcular el área del rectángulo con base y altura (A y B en este caso)
        double areaRectangulo = calcularAreaRectangulo(ladoA, ladoB);

        // Calcular el área total del terreno
        // Suponiendo que el terreno está compuesto por un triángulo rectángulo y un rectángulo
        double areaTotal = areaTriangulo + areaRectangulo;

        // Calcular el perímetro del terreno
        double perimetro = calcularPerimetro(ladoA, ladoB, ladoC);

        // Mostrar los resultados
        System.out.printf("El área del triángulo es: %.2f metros cuadrados%n", areaTriangulo);
        System.out.printf("El área del rectángulo es: %.2f metros cuadrados%n", areaRectangulo);
        System.out.printf("El área total del terreno es: %.2f metros cuadrados%n", areaTotal);
        System.out.printf("El perímetro del terreno es: %.2f metros%n", perimetro);

        // Cerrar el scanner
        scanner.close();
    }
}


