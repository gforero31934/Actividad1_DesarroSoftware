
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Carrera {

    /**
     * Default constructor
     */
    public Carrera() {
    }

    /**
     * 
     */
    public Int Id;

    /**
     * 
     */
    public String Nombre_Carrera;

    /**
     * 
     */
    public Int Numero_Total_Creditos;

    /**
     * 
     */
    public Int Numero_Semestres;

    /**
     * 
     */
    public String Nivel;

    /**
     * 
     */
    public void Agregar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Editar() {
        // TODO implement here
    }

}