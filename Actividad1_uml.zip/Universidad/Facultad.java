
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Facultad {

    /**
     * Default constructor
     */
    public Facultad() {
    }

    /**
     * 
     */
    public String Nombre_Facultad;

    /**
     * 
     */
    public Int Id_Faculad;

    /**
     * 
     */
    public void Agregar_Facultad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Editar_Facultad() {
        // TODO implement here
    }

}