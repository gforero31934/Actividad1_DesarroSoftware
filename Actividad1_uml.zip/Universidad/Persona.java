
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Persona {

    /**
     * Default constructor
     */
    public Persona() {
    }

    /**
     * 
     */
    public Int Cedula;

    /**
     * 
     */
    public String Nombre_Persona;

    /**
     * 
     */
    public String Genero;

    /**
     * 
     */
    public String Edad;

    /**
     * 
     */
    public String Direccion_Persona;

    /**
     * 
     */
    public String Fecha_Nacimiento;

    /**
     * 
     */
    public String Lugar_Nacimiento;

    /**
     * 
     */
    public void Agregar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Editar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Eliminar() {
        // TODO implement here
    }

}