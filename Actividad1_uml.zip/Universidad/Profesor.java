
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Profesor extends Persona {

    /**
     * Default constructor
     */
    public Profesor() {
    }

    /**
     * 
     */
    public String Profesion;

    /**
     * 
     */
    public String Nacionalidad;

    /**
     * 
     */
    public float Salario;

    /**
     * 
     */
    public void Agregar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Editar() {
        // TODO implement here
    }

}