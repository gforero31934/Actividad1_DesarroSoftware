
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Universidad {

    /**
     * Default constructor
     */
    public Universidad() {
    }

    /**
     * 
     */
    public Int Nit;

    /**
     * 
     */
    public String Nombre_Universidad;

    /**
     * 
     */
    public String Direccion_Universidad;

    /**
     * 
     */
    public String Nombre_Rector;

    /**
     * 
     */
    public String ID_Rector;

    /**
     * 
     */
    public void Agregar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Editar() {
        // TODO implement here
    }

}